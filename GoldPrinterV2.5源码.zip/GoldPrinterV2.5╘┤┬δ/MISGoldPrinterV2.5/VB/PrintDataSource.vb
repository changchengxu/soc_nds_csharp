
Public Class PrintDataSource
    Public Shared Function GetDataSource(ByVal p_DataRows As Int32) As System.Data.DataTable
        Dim dt As New System.Data.DataTable
        Dim rows, cols As Int32
        rows = p_DataRows
        cols = 6

        Dim i, j As Int32
        i = 0
        While (i < rows)
            dt.Rows.Add(dt.NewRow())
            i += 1
        End While

        i = 0
        While (i < cols)
            dt.Columns.Add()
            dt.Columns(i).DefaultValue = ""
            i += 1
        End While

        For i = 0 To rows - 1
            dt.Rows(i)(0) = (i + 1).ToString()  '����
            For j = 0 To cols - 1
                dt.Rows(i)(j) = (i + 1).ToString() + "��" + (j + 1).ToString() + "��"
                dt.Rows(i)(cols - 3) = (j + 1).ToString() + "." + (i + 1).ToString()
                dt.Rows(i)(cols - 2) = (i + 1).ToString()
            Next
            dt.Rows(i)(cols - 1) = (Double.Parse(dt.Rows(i)(cols - 2).ToString()) * Double.Parse(dt.Rows(i)(cols - 3).ToString())).ToString()
        Next

        Return dt

    End Function

End Class
