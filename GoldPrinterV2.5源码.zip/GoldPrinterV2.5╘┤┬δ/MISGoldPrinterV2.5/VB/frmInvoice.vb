Public Class frmInvoice
    Inherits System.Windows.Forms.Form

#Region " Windows ������������ɵĴ��� "

    Public Sub New()
        MyBase.New()

        '�õ����� Windows ���������������ġ�
        InitializeComponent()

        '�� InitializeComponent() ����֮�������κγ�ʼ��

    End Sub

    '������д dispose ����������б���
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Windows ����������������
    Private components As System.ComponentModel.IContainer

    'ע��: ���¹����� Windows ����������������
    '����ʹ�� Windows ����������޸Ĵ˹��̡�
    '��Ҫʹ�ô���༭���޸�����
    Friend WithEvents txtTaxControlCode As System.Windows.Forms.TextBox
    Friend WithEvents cldSelect As System.Windows.Forms.MonthCalendar
    Friend WithEvents txtWriter As System.Windows.Forms.TextBox
    Friend WithEvents btnCasePrint As System.Windows.Forms.Button
    Friend WithEvents btnPreview As System.Windows.Forms.Button
    Friend WithEvents btnPrint As System.Windows.Forms.Button
    Friend WithEvents panel1 As System.Windows.Forms.Panel
    Friend WithEvents cboTaxRate As System.Windows.Forms.ComboBox
    Friend WithEvents label24 As System.Windows.Forms.Label
    Friend WithEvents txtTaxLower As System.Windows.Forms.TextBox
    Friend WithEvents txtTotalLower As System.Windows.Forms.TextBox
    Friend WithEvents label20 As System.Windows.Forms.Label
    Friend WithEvents label21 As System.Windows.Forms.Label
    Friend WithEvents label19 As System.Windows.Forms.Label
    Friend WithEvents txtTaxUpper As System.Windows.Forms.TextBox
    Friend WithEvents label18 As System.Windows.Forms.Label
    Friend WithEvents txtTotalUpper As System.Windows.Forms.TextBox
    Friend WithEvents label16 As System.Windows.Forms.Label
    Friend WithEvents label15 As System.Windows.Forms.Label
    Friend WithEvents label14 As System.Windows.Forms.Label
    Friend WithEvents txtMemo As System.Windows.Forms.TextBox
    Friend WithEvents txtJ10 As System.Windows.Forms.TextBox
    Friend WithEvents txtP10 As System.Windows.Forms.TextBox
    Friend WithEvents txtJ9 As System.Windows.Forms.TextBox
    Friend WithEvents txtP9 As System.Windows.Forms.TextBox
    Friend WithEvents txtJ8 As System.Windows.Forms.TextBox
    Friend WithEvents txtP8 As System.Windows.Forms.TextBox
    Friend WithEvents txtJ7 As System.Windows.Forms.TextBox
    Friend WithEvents txtP7 As System.Windows.Forms.TextBox
    Friend WithEvents txtJ6 As System.Windows.Forms.TextBox
    Friend WithEvents txtP6 As System.Windows.Forms.TextBox
    Friend WithEvents txtJ5 As System.Windows.Forms.TextBox
    Friend WithEvents txtP5 As System.Windows.Forms.TextBox
    Friend WithEvents txtJ4 As System.Windows.Forms.TextBox
    Friend WithEvents txtP4 As System.Windows.Forms.TextBox
    Friend WithEvents txtJ3 As System.Windows.Forms.TextBox
    Friend WithEvents txtP3 As System.Windows.Forms.TextBox
    Friend WithEvents txtJ2 As System.Windows.Forms.TextBox
    Friend WithEvents txtP2 As System.Windows.Forms.TextBox
    Friend WithEvents txtJ1 As System.Windows.Forms.TextBox
    Friend WithEvents txtP1 As System.Windows.Forms.TextBox
    Friend WithEvents label34 As System.Windows.Forms.Label
    Friend WithEvents label33 As System.Windows.Forms.Label
    Friend WithEvents txtCollecterID As System.Windows.Forms.TextBox
    Friend WithEvents txtInvoiceApplicationNo As System.Windows.Forms.TextBox
    Friend WithEvents label31 As System.Windows.Forms.Label
    Friend WithEvents label32 As System.Windows.Forms.Label
    Friend WithEvents label29 As System.Windows.Forms.Label
    Friend WithEvents label30 As System.Windows.Forms.Label
    Friend WithEvents txtCollecterAddTel As System.Windows.Forms.TextBox
    Friend WithEvents txtCollecter As System.Windows.Forms.TextBox
    Friend WithEvents txtPayer As System.Windows.Forms.TextBox
    Friend WithEvents pictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents label17 As System.Windows.Forms.Label
    Friend WithEvents label13 As System.Windows.Forms.Label
    Friend WithEvents label12 As System.Windows.Forms.Label
    Friend WithEvents label11 As System.Windows.Forms.Label
    Friend WithEvents label10 As System.Windows.Forms.Label
    Friend WithEvents label9 As System.Windows.Forms.Label
    Friend WithEvents label8 As System.Windows.Forms.Label
    Friend WithEvents btnRefDate As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents label23 As System.Windows.Forms.Label
    Friend WithEvents label22 As System.Windows.Forms.Label
    Friend WithEvents label7 As System.Windows.Forms.Label
    Friend WithEvents label6 As System.Windows.Forms.Label
    Friend WithEvents label5 As System.Windows.Forms.Label
    Friend WithEvents txtDay As System.Windows.Forms.TextBox
    Friend WithEvents txtMonth As System.Windows.Forms.TextBox
    Friend WithEvents txtYear As System.Windows.Forms.TextBox
    Friend WithEvents txtInvoiceSerialNo As System.Windows.Forms.TextBox
    Friend WithEvents txtInvoiceCode As System.Windows.Forms.TextBox
    Friend WithEvents label4 As System.Windows.Forms.Label
    Friend WithEvents label3 As System.Windows.Forms.Label
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents label1 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.txtTaxControlCode = New System.Windows.Forms.TextBox
        Me.cldSelect = New System.Windows.Forms.MonthCalendar
        Me.txtWriter = New System.Windows.Forms.TextBox
        Me.btnCasePrint = New System.Windows.Forms.Button
        Me.btnPreview = New System.Windows.Forms.Button
        Me.btnPrint = New System.Windows.Forms.Button
        Me.panel1 = New System.Windows.Forms.Panel
        Me.cboTaxRate = New System.Windows.Forms.ComboBox
        Me.label24 = New System.Windows.Forms.Label
        Me.txtTaxLower = New System.Windows.Forms.TextBox
        Me.txtTotalLower = New System.Windows.Forms.TextBox
        Me.label20 = New System.Windows.Forms.Label
        Me.label21 = New System.Windows.Forms.Label
        Me.label19 = New System.Windows.Forms.Label
        Me.txtTaxUpper = New System.Windows.Forms.TextBox
        Me.label18 = New System.Windows.Forms.Label
        Me.txtTotalUpper = New System.Windows.Forms.TextBox
        Me.label16 = New System.Windows.Forms.Label
        Me.label15 = New System.Windows.Forms.Label
        Me.label14 = New System.Windows.Forms.Label
        Me.txtMemo = New System.Windows.Forms.TextBox
        Me.txtJ10 = New System.Windows.Forms.TextBox
        Me.txtP10 = New System.Windows.Forms.TextBox
        Me.txtJ9 = New System.Windows.Forms.TextBox
        Me.txtP9 = New System.Windows.Forms.TextBox
        Me.txtJ8 = New System.Windows.Forms.TextBox
        Me.txtP8 = New System.Windows.Forms.TextBox
        Me.txtJ7 = New System.Windows.Forms.TextBox
        Me.txtP7 = New System.Windows.Forms.TextBox
        Me.txtJ6 = New System.Windows.Forms.TextBox
        Me.txtP6 = New System.Windows.Forms.TextBox
        Me.txtJ5 = New System.Windows.Forms.TextBox
        Me.txtP5 = New System.Windows.Forms.TextBox
        Me.txtJ4 = New System.Windows.Forms.TextBox
        Me.txtP4 = New System.Windows.Forms.TextBox
        Me.txtJ3 = New System.Windows.Forms.TextBox
        Me.txtP3 = New System.Windows.Forms.TextBox
        Me.txtJ2 = New System.Windows.Forms.TextBox
        Me.txtP2 = New System.Windows.Forms.TextBox
        Me.txtJ1 = New System.Windows.Forms.TextBox
        Me.txtP1 = New System.Windows.Forms.TextBox
        Me.label34 = New System.Windows.Forms.Label
        Me.label33 = New System.Windows.Forms.Label
        Me.txtCollecterID = New System.Windows.Forms.TextBox
        Me.txtInvoiceApplicationNo = New System.Windows.Forms.TextBox
        Me.label31 = New System.Windows.Forms.Label
        Me.label32 = New System.Windows.Forms.Label
        Me.label29 = New System.Windows.Forms.Label
        Me.label30 = New System.Windows.Forms.Label
        Me.txtCollecterAddTel = New System.Windows.Forms.TextBox
        Me.txtCollecter = New System.Windows.Forms.TextBox
        Me.txtPayer = New System.Windows.Forms.TextBox
        Me.pictureBox1 = New System.Windows.Forms.PictureBox
        Me.label17 = New System.Windows.Forms.Label
        Me.label13 = New System.Windows.Forms.Label
        Me.label12 = New System.Windows.Forms.Label
        Me.label11 = New System.Windows.Forms.Label
        Me.label10 = New System.Windows.Forms.Label
        Me.label9 = New System.Windows.Forms.Label
        Me.label8 = New System.Windows.Forms.Label
        Me.btnRefDate = New System.Windows.Forms.Button
        Me.btnExit = New System.Windows.Forms.Button
        Me.label23 = New System.Windows.Forms.Label
        Me.label22 = New System.Windows.Forms.Label
        Me.label7 = New System.Windows.Forms.Label
        Me.label6 = New System.Windows.Forms.Label
        Me.label5 = New System.Windows.Forms.Label
        Me.txtDay = New System.Windows.Forms.TextBox
        Me.txtMonth = New System.Windows.Forms.TextBox
        Me.txtYear = New System.Windows.Forms.TextBox
        Me.txtInvoiceSerialNo = New System.Windows.Forms.TextBox
        Me.txtInvoiceCode = New System.Windows.Forms.TextBox
        Me.label4 = New System.Windows.Forms.Label
        Me.label3 = New System.Windows.Forms.Label
        Me.label2 = New System.Windows.Forms.Label
        Me.label1 = New System.Windows.Forms.Label
        Me.panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtTaxControlCode
        '
        Me.txtTaxControlCode.Location = New System.Drawing.Point(62, 489)
        Me.txtTaxControlCode.Name = "txtTaxControlCode"
        Me.txtTaxControlCode.Size = New System.Drawing.Size(324, 21)
        Me.txtTaxControlCode.TabIndex = 56
        Me.txtTaxControlCode.Text = ""
        '
        'cldSelect
        '
        Me.cldSelect.Location = New System.Drawing.Point(169, 70)
        Me.cldSelect.MaxDate = New Date(2999, 12, 31, 0, 0, 0, 0)
        Me.cldSelect.MaxSelectionCount = 1
        Me.cldSelect.MinDate = New Date(1949, 1, 1, 0, 0, 0, 0)
        Me.cldSelect.Name = "cldSelect"
        Me.cldSelect.TabIndex = 62
        Me.cldSelect.TabStop = False
        Me.cldSelect.Visible = False
        '
        'txtWriter
        '
        Me.txtWriter.Location = New System.Drawing.Point(458, 489)
        Me.txtWriter.Name = "txtWriter"
        Me.txtWriter.Size = New System.Drawing.Size(324, 21)
        Me.txtWriter.TabIndex = 57
        Me.txtWriter.Text = ""
        '
        'btnCasePrint
        '
        Me.btnCasePrint.Location = New System.Drawing.Point(400, 515)
        Me.btnCasePrint.Name = "btnCasePrint"
        Me.btnCasePrint.TabIndex = 58
        Me.btnCasePrint.Tag = "�״�"
        Me.btnCasePrint.Text = "�״�(&T)"
        '
        'btnPreview
        '
        Me.btnPreview.Location = New System.Drawing.Point(562, 515)
        Me.btnPreview.Name = "btnPreview"
        Me.btnPreview.TabIndex = 60
        Me.btnPreview.Tag = "Ԥ��"
        Me.btnPreview.Text = "Ԥ��(&V)"
        '
        'btnPrint
        '
        Me.btnPrint.Location = New System.Drawing.Point(480, 515)
        Me.btnPrint.Name = "btnPrint"
        Me.btnPrint.TabIndex = 59
        Me.btnPrint.Tag = "��ӡ"
        Me.btnPrint.Text = "��ӡ(&P)"
        '
        'panel1
        '
        Me.panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.panel1.Controls.Add(Me.cboTaxRate)
        Me.panel1.Controls.Add(Me.label24)
        Me.panel1.Controls.Add(Me.txtTaxLower)
        Me.panel1.Controls.Add(Me.txtTotalLower)
        Me.panel1.Controls.Add(Me.label20)
        Me.panel1.Controls.Add(Me.label21)
        Me.panel1.Controls.Add(Me.label19)
        Me.panel1.Controls.Add(Me.txtTaxUpper)
        Me.panel1.Controls.Add(Me.label18)
        Me.panel1.Controls.Add(Me.txtTotalUpper)
        Me.panel1.Controls.Add(Me.label16)
        Me.panel1.Controls.Add(Me.label15)
        Me.panel1.Controls.Add(Me.label14)
        Me.panel1.Controls.Add(Me.txtMemo)
        Me.panel1.Controls.Add(Me.txtJ10)
        Me.panel1.Controls.Add(Me.txtP10)
        Me.panel1.Controls.Add(Me.txtJ9)
        Me.panel1.Controls.Add(Me.txtP9)
        Me.panel1.Controls.Add(Me.txtJ8)
        Me.panel1.Controls.Add(Me.txtP8)
        Me.panel1.Controls.Add(Me.txtJ7)
        Me.panel1.Controls.Add(Me.txtP7)
        Me.panel1.Controls.Add(Me.txtJ6)
        Me.panel1.Controls.Add(Me.txtP6)
        Me.panel1.Controls.Add(Me.txtJ5)
        Me.panel1.Controls.Add(Me.txtP5)
        Me.panel1.Controls.Add(Me.txtJ4)
        Me.panel1.Controls.Add(Me.txtP4)
        Me.panel1.Controls.Add(Me.txtJ3)
        Me.panel1.Controls.Add(Me.txtP3)
        Me.panel1.Controls.Add(Me.txtJ2)
        Me.panel1.Controls.Add(Me.txtP2)
        Me.panel1.Controls.Add(Me.txtJ1)
        Me.panel1.Controls.Add(Me.txtP1)
        Me.panel1.Controls.Add(Me.label34)
        Me.panel1.Controls.Add(Me.label33)
        Me.panel1.Controls.Add(Me.txtCollecterID)
        Me.panel1.Controls.Add(Me.txtInvoiceApplicationNo)
        Me.panel1.Controls.Add(Me.label31)
        Me.panel1.Controls.Add(Me.label32)
        Me.panel1.Controls.Add(Me.label29)
        Me.panel1.Controls.Add(Me.label30)
        Me.panel1.Controls.Add(Me.txtCollecterAddTel)
        Me.panel1.Controls.Add(Me.txtCollecter)
        Me.panel1.Controls.Add(Me.txtPayer)
        Me.panel1.Controls.Add(Me.pictureBox1)
        Me.panel1.Controls.Add(Me.label17)
        Me.panel1.Controls.Add(Me.label13)
        Me.panel1.Controls.Add(Me.label12)
        Me.panel1.Controls.Add(Me.label11)
        Me.panel1.Controls.Add(Me.label10)
        Me.panel1.Controls.Add(Me.label9)
        Me.panel1.Controls.Add(Me.label8)
        Me.panel1.Location = New System.Drawing.Point(4, 95)
        Me.panel1.Name = "panel1"
        Me.panel1.Size = New System.Drawing.Size(784, 390)
        Me.panel1.TabIndex = 50
        '
        'cboTaxRate
        '
        Me.cboTaxRate.Items.AddRange(New Object() {"7", "13", "15", "17"})
        Me.cboTaxRate.Location = New System.Drawing.Point(616, 306)
        Me.cboTaxRate.Name = "cboTaxRate"
        Me.cboTaxRate.Size = New System.Drawing.Size(52, 20)
        Me.cboTaxRate.TabIndex = 27
        Me.cboTaxRate.TabStop = False
        Me.cboTaxRate.Text = "7"
        '
        'label24
        '
        Me.label24.Location = New System.Drawing.Point(538, 306)
        Me.label24.Name = "label24"
        Me.label24.Size = New System.Drawing.Size(88, 22)
        Me.label24.TabIndex = 68
        Me.label24.Text = "˰������(%)��"
        Me.label24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtTaxLower
        '
        Me.txtTaxLower.Location = New System.Drawing.Point(618, 362)
        Me.txtTaxLower.Name = "txtTaxLower"
        Me.txtTaxLower.Size = New System.Drawing.Size(158, 21)
        Me.txtTaxLower.TabIndex = 31
        Me.txtTaxLower.Text = ""
        '
        'txtTotalLower
        '
        Me.txtTotalLower.Location = New System.Drawing.Point(618, 336)
        Me.txtTotalLower.Name = "txtTotalLower"
        Me.txtTotalLower.Size = New System.Drawing.Size(158, 21)
        Me.txtTotalLower.TabIndex = 29
        Me.txtTotalLower.Text = ""
        '
        'label20
        '
        Me.label20.Location = New System.Drawing.Point(534, 362)
        Me.label20.Name = "label20"
        Me.label20.Size = New System.Drawing.Size(80, 18)
        Me.label20.TabIndex = 63
        Me.label20.Text = "��˰ƾ֤����"
        Me.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label21
        '
        Me.label21.Location = New System.Drawing.Point(534, 336)
        Me.label21.Name = "label21"
        Me.label21.Size = New System.Drawing.Size(80, 18)
        Me.label21.TabIndex = 62
        Me.label21.Text = "(Сд)"
        Me.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label19
        '
        Me.label19.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.label19.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.label19.Location = New System.Drawing.Point(6, 356)
        Me.label19.Name = "label19"
        Me.label19.Size = New System.Drawing.Size(768, 3)
        Me.label19.TabIndex = 61
        '
        'txtTaxUpper
        '
        Me.txtTaxUpper.Location = New System.Drawing.Point(114, 360)
        Me.txtTaxUpper.Name = "txtTaxUpper"
        Me.txtTaxUpper.Size = New System.Drawing.Size(416, 21)
        Me.txtTaxUpper.TabIndex = 30
        Me.txtTaxUpper.Text = ""
        '
        'label18
        '
        Me.label18.Location = New System.Drawing.Point(6, 362)
        Me.label18.Name = "label18"
        Me.label18.Size = New System.Drawing.Size(104, 18)
        Me.label18.TabIndex = 59
        Me.label18.Text = "˰��(��д)"
        Me.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtTotalUpper
        '
        Me.txtTotalUpper.Location = New System.Drawing.Point(114, 334)
        Me.txtTotalUpper.Name = "txtTotalUpper"
        Me.txtTotalUpper.Size = New System.Drawing.Size(416, 21)
        Me.txtTotalUpper.TabIndex = 28
        Me.txtTotalUpper.Text = ""
        '
        'label16
        '
        Me.label16.Location = New System.Drawing.Point(6, 336)
        Me.label16.Name = "label16"
        Me.label16.Size = New System.Drawing.Size(104, 18)
        Me.label16.TabIndex = 57
        Me.label16.Text = "�ϼ������(��д)"
        Me.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label15
        '
        Me.label15.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.label15.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.label15.Location = New System.Drawing.Point(6, 328)
        Me.label15.Name = "label15"
        Me.label15.Size = New System.Drawing.Size(768, 3)
        Me.label15.TabIndex = 56
        '
        'label14
        '
        Me.label14.Location = New System.Drawing.Point(666, 308)
        Me.label14.Name = "label14"
        Me.label14.Size = New System.Drawing.Size(102, 18)
        Me.label14.TabIndex = 55
        Me.label14.Text = "������λ����"
        Me.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtMemo
        '
        Me.txtMemo.Location = New System.Drawing.Point(538, 126)
        Me.txtMemo.Multiline = True
        Me.txtMemo.Name = "txtMemo"
        Me.txtMemo.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtMemo.Size = New System.Drawing.Size(230, 178)
        Me.txtMemo.TabIndex = 27
        Me.txtMemo.Text = ""
        '
        'txtJ10
        '
        Me.txtJ10.Font = New System.Drawing.Font("����", 8.0!)
        Me.txtJ10.Location = New System.Drawing.Point(440, 304)
        Me.txtJ10.Name = "txtJ10"
        Me.txtJ10.Size = New System.Drawing.Size(88, 20)
        Me.txtJ10.TabIndex = 26
        Me.txtJ10.Text = ""
        Me.txtJ10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtP10
        '
        Me.txtP10.Font = New System.Drawing.Font("����", 8.0!)
        Me.txtP10.Location = New System.Drawing.Point(6, 304)
        Me.txtP10.Name = "txtP10"
        Me.txtP10.Size = New System.Drawing.Size(430, 20)
        Me.txtP10.TabIndex = 25
        Me.txtP10.Text = ""
        '
        'txtJ9
        '
        Me.txtJ9.Font = New System.Drawing.Font("����", 8.0!)
        Me.txtJ9.Location = New System.Drawing.Point(440, 284)
        Me.txtJ9.Name = "txtJ9"
        Me.txtJ9.Size = New System.Drawing.Size(88, 20)
        Me.txtJ9.TabIndex = 24
        Me.txtJ9.Text = ""
        Me.txtJ9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtP9
        '
        Me.txtP9.Font = New System.Drawing.Font("����", 8.0!)
        Me.txtP9.Location = New System.Drawing.Point(6, 284)
        Me.txtP9.Name = "txtP9"
        Me.txtP9.Size = New System.Drawing.Size(430, 20)
        Me.txtP9.TabIndex = 23
        Me.txtP9.Text = ""
        '
        'txtJ8
        '
        Me.txtJ8.Font = New System.Drawing.Font("����", 8.0!)
        Me.txtJ8.Location = New System.Drawing.Point(440, 264)
        Me.txtJ8.Name = "txtJ8"
        Me.txtJ8.Size = New System.Drawing.Size(88, 20)
        Me.txtJ8.TabIndex = 22
        Me.txtJ8.Text = ""
        Me.txtJ8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtP8
        '
        Me.txtP8.Font = New System.Drawing.Font("����", 8.0!)
        Me.txtP8.Location = New System.Drawing.Point(6, 264)
        Me.txtP8.Name = "txtP8"
        Me.txtP8.Size = New System.Drawing.Size(430, 20)
        Me.txtP8.TabIndex = 21
        Me.txtP8.Text = ""
        '
        'txtJ7
        '
        Me.txtJ7.Font = New System.Drawing.Font("����", 8.0!)
        Me.txtJ7.Location = New System.Drawing.Point(440, 244)
        Me.txtJ7.Name = "txtJ7"
        Me.txtJ7.Size = New System.Drawing.Size(88, 20)
        Me.txtJ7.TabIndex = 20
        Me.txtJ7.Text = ""
        Me.txtJ7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtP7
        '
        Me.txtP7.Font = New System.Drawing.Font("����", 8.0!)
        Me.txtP7.Location = New System.Drawing.Point(6, 244)
        Me.txtP7.Name = "txtP7"
        Me.txtP7.Size = New System.Drawing.Size(430, 20)
        Me.txtP7.TabIndex = 19
        Me.txtP7.Text = ""
        '
        'txtJ6
        '
        Me.txtJ6.Font = New System.Drawing.Font("����", 8.0!)
        Me.txtJ6.Location = New System.Drawing.Point(440, 224)
        Me.txtJ6.Name = "txtJ6"
        Me.txtJ6.Size = New System.Drawing.Size(88, 20)
        Me.txtJ6.TabIndex = 18
        Me.txtJ6.Text = ""
        Me.txtJ6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtP6
        '
        Me.txtP6.Font = New System.Drawing.Font("����", 8.0!)
        Me.txtP6.Location = New System.Drawing.Point(6, 224)
        Me.txtP6.Name = "txtP6"
        Me.txtP6.Size = New System.Drawing.Size(430, 20)
        Me.txtP6.TabIndex = 17
        Me.txtP6.Text = ""
        '
        'txtJ5
        '
        Me.txtJ5.Font = New System.Drawing.Font("����", 8.0!)
        Me.txtJ5.Location = New System.Drawing.Point(440, 204)
        Me.txtJ5.Name = "txtJ5"
        Me.txtJ5.Size = New System.Drawing.Size(88, 20)
        Me.txtJ5.TabIndex = 16
        Me.txtJ5.Text = ""
        Me.txtJ5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtP5
        '
        Me.txtP5.Font = New System.Drawing.Font("����", 8.0!)
        Me.txtP5.Location = New System.Drawing.Point(6, 204)
        Me.txtP5.Name = "txtP5"
        Me.txtP5.Size = New System.Drawing.Size(430, 20)
        Me.txtP5.TabIndex = 15
        Me.txtP5.Text = ""
        '
        'txtJ4
        '
        Me.txtJ4.Font = New System.Drawing.Font("����", 8.0!)
        Me.txtJ4.Location = New System.Drawing.Point(440, 184)
        Me.txtJ4.Name = "txtJ4"
        Me.txtJ4.Size = New System.Drawing.Size(88, 20)
        Me.txtJ4.TabIndex = 14
        Me.txtJ4.Text = ""
        Me.txtJ4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtP4
        '
        Me.txtP4.Font = New System.Drawing.Font("����", 8.0!)
        Me.txtP4.Location = New System.Drawing.Point(6, 184)
        Me.txtP4.Name = "txtP4"
        Me.txtP4.Size = New System.Drawing.Size(430, 20)
        Me.txtP4.TabIndex = 13
        Me.txtP4.Text = ""
        '
        'txtJ3
        '
        Me.txtJ3.Font = New System.Drawing.Font("����", 8.0!)
        Me.txtJ3.Location = New System.Drawing.Point(440, 164)
        Me.txtJ3.Name = "txtJ3"
        Me.txtJ3.Size = New System.Drawing.Size(88, 20)
        Me.txtJ3.TabIndex = 12
        Me.txtJ3.Text = ""
        Me.txtJ3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtP3
        '
        Me.txtP3.Font = New System.Drawing.Font("����", 8.0!)
        Me.txtP3.Location = New System.Drawing.Point(6, 164)
        Me.txtP3.Name = "txtP3"
        Me.txtP3.Size = New System.Drawing.Size(430, 20)
        Me.txtP3.TabIndex = 11
        Me.txtP3.Text = ""
        '
        'txtJ2
        '
        Me.txtJ2.Font = New System.Drawing.Font("����", 8.0!)
        Me.txtJ2.Location = New System.Drawing.Point(440, 144)
        Me.txtJ2.Name = "txtJ2"
        Me.txtJ2.Size = New System.Drawing.Size(88, 20)
        Me.txtJ2.TabIndex = 10
        Me.txtJ2.Text = ""
        Me.txtJ2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtP2
        '
        Me.txtP2.Font = New System.Drawing.Font("����", 8.0!)
        Me.txtP2.Location = New System.Drawing.Point(6, 144)
        Me.txtP2.Name = "txtP2"
        Me.txtP2.Size = New System.Drawing.Size(430, 20)
        Me.txtP2.TabIndex = 9
        Me.txtP2.Text = ""
        '
        'txtJ1
        '
        Me.txtJ1.Font = New System.Drawing.Font("����", 8.0!)
        Me.txtJ1.Location = New System.Drawing.Point(440, 124)
        Me.txtJ1.Name = "txtJ1"
        Me.txtJ1.Size = New System.Drawing.Size(88, 20)
        Me.txtJ1.TabIndex = 8
        Me.txtJ1.Text = ""
        Me.txtJ1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtP1
        '
        Me.txtP1.Font = New System.Drawing.Font("����", 8.0!)
        Me.txtP1.Location = New System.Drawing.Point(6, 124)
        Me.txtP1.Name = "txtP1"
        Me.txtP1.Size = New System.Drawing.Size(430, 20)
        Me.txtP1.TabIndex = 7
        Me.txtP1.Text = ""
        '
        'label34
        '
        Me.label34.Location = New System.Drawing.Point(538, 94)
        Me.label34.Name = "label34"
        Me.label34.Size = New System.Drawing.Size(230, 22)
        Me.label34.TabIndex = 33
        Me.label34.Text = "��           ע"
        Me.label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label33
        '
        Me.label33.Location = New System.Drawing.Point(8, 94)
        Me.label33.Name = "label33"
        Me.label33.Size = New System.Drawing.Size(520, 22)
        Me.label33.TabIndex = 32
        Me.label33.Text = "Ʒ       Ŀ       ��       ��       ��"
        Me.label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtCollecterID
        '
        Me.txtCollecterID.Location = New System.Drawing.Point(494, 58)
        Me.txtCollecterID.Name = "txtCollecterID"
        Me.txtCollecterID.Size = New System.Drawing.Size(282, 21)
        Me.txtCollecterID.TabIndex = 6
        Me.txtCollecterID.Text = ""
        '
        'txtInvoiceApplicationNo
        '
        Me.txtInvoiceApplicationNo.Location = New System.Drawing.Point(494, 18)
        Me.txtInvoiceApplicationNo.Name = "txtInvoiceApplicationNo"
        Me.txtInvoiceApplicationNo.Size = New System.Drawing.Size(282, 21)
        Me.txtInvoiceApplicationNo.TabIndex = 3
        Me.txtInvoiceApplicationNo.Text = ""
        '
        'label31
        '
        Me.label31.Location = New System.Drawing.Point(398, 70)
        Me.label31.Name = "label31"
        Me.label31.Size = New System.Drawing.Size(92, 18)
        Me.label31.TabIndex = 29
        Me.label31.Text = "�� ֤ �� �� ��"
        Me.label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label32
        '
        Me.label32.Location = New System.Drawing.Point(398, 50)
        Me.label32.Name = "label32"
        Me.label32.Size = New System.Drawing.Size(92, 18)
        Me.label32.TabIndex = 28
        Me.label32.Text = "�տʶ���"
        Me.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label29
        '
        Me.label29.Location = New System.Drawing.Point(398, 26)
        Me.label29.Name = "label29"
        Me.label29.Size = New System.Drawing.Size(92, 18)
        Me.label29.TabIndex = 27
        Me.label29.Text = "�� �� �� �� ��"
        Me.label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label30
        '
        Me.label30.Location = New System.Drawing.Point(398, 6)
        Me.label30.Name = "label30"
        Me.label30.Size = New System.Drawing.Size(92, 18)
        Me.label30.TabIndex = 26
        Me.label30.Text = "������ͨ��Ʊ"
        Me.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtCollecterAddTel
        '
        Me.txtCollecterAddTel.Location = New System.Drawing.Point(104, 68)
        Me.txtCollecterAddTel.Name = "txtCollecterAddTel"
        Me.txtCollecterAddTel.Size = New System.Drawing.Size(282, 21)
        Me.txtCollecterAddTel.TabIndex = 5
        Me.txtCollecterAddTel.Text = ""
        '
        'txtCollecter
        '
        Me.txtCollecter.Location = New System.Drawing.Point(104, 48)
        Me.txtCollecter.Name = "txtCollecter"
        Me.txtCollecter.Size = New System.Drawing.Size(282, 21)
        Me.txtCollecter.TabIndex = 4
        Me.txtCollecter.Text = ""
        '
        'txtPayer
        '
        Me.txtPayer.Location = New System.Drawing.Point(104, 12)
        Me.txtPayer.Name = "txtPayer"
        Me.txtPayer.Size = New System.Drawing.Size(282, 21)
        Me.txtPayer.TabIndex = 2
        Me.txtPayer.Text = ""
        '
        'pictureBox1
        '
        Me.pictureBox1.Location = New System.Drawing.Point(390, 8)
        Me.pictureBox1.Name = "pictureBox1"
        Me.pictureBox1.Size = New System.Drawing.Size(3, 80)
        Me.pictureBox1.TabIndex = 22
        Me.pictureBox1.TabStop = False
        '
        'label17
        '
        Me.label17.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.label17.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.label17.Location = New System.Drawing.Point(6, 116)
        Me.label17.Name = "label17"
        Me.label17.Size = New System.Drawing.Size(768, 3)
        Me.label17.TabIndex = 10
        '
        'label13
        '
        Me.label13.Location = New System.Drawing.Point(8, 70)
        Me.label13.Name = "label13"
        Me.label13.Size = New System.Drawing.Size(92, 18)
        Me.label13.TabIndex = 6
        Me.label13.Text = "����ַ���绰"
        Me.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label12
        '
        Me.label12.Location = New System.Drawing.Point(8, 50)
        Me.label12.Name = "label12"
        Me.label12.Size = New System.Drawing.Size(92, 18)
        Me.label12.TabIndex = 5
        Me.label12.Text = "�տ����"
        Me.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label11
        '
        Me.label11.Location = New System.Drawing.Point(8, 6)
        Me.label11.Name = "label11"
        Me.label11.Size = New System.Drawing.Size(92, 36)
        Me.label11.TabIndex = 4
        Me.label11.Text = "�������"
        Me.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label10
        '
        Me.label10.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.label10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.label10.Location = New System.Drawing.Point(6, 88)
        Me.label10.Name = "label10"
        Me.label10.Size = New System.Drawing.Size(768, 3)
        Me.label10.TabIndex = 2
        Me.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label9
        '
        Me.label9.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.label9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.label9.Location = New System.Drawing.Point(6, 44)
        Me.label9.Name = "label9"
        Me.label9.Size = New System.Drawing.Size(768, 3)
        Me.label9.TabIndex = 1
        '
        'label8
        '
        Me.label8.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.label8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.label8.Location = New System.Drawing.Point(4, -10)
        Me.label8.Name = "label8"
        Me.label8.Size = New System.Drawing.Size(768, 10)
        Me.label8.TabIndex = 0
        '
        'btnRefDate
        '
        Me.btnRefDate.Location = New System.Drawing.Point(134, 69)
        Me.btnRefDate.Name = "btnRefDate"
        Me.btnRefDate.Size = New System.Drawing.Size(32, 23)
        Me.btnRefDate.TabIndex = 40
        Me.btnRefDate.TabStop = False
        Me.btnRefDate.Text = "..."
        '
        'btnExit
        '
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnExit.Location = New System.Drawing.Point(708, 515)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.TabIndex = 61
        Me.btnExit.Text = "�˳�(&X)"
        '
        'label23
        '
        Me.label23.Location = New System.Drawing.Point(402, 489)
        Me.label23.Name = "label23"
        Me.label23.Size = New System.Drawing.Size(54, 22)
        Me.label23.TabIndex = 55
        Me.label23.Text = "��Ʊ�ˣ�"
        Me.label23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'label22
        '
        Me.label22.Location = New System.Drawing.Point(6, 489)
        Me.label22.Name = "label22"
        Me.label22.Size = New System.Drawing.Size(54, 22)
        Me.label22.TabIndex = 54
        Me.label22.Text = "˰���룺"
        Me.label22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'label7
        '
        Me.label7.Location = New System.Drawing.Point(112, 71)
        Me.label7.Name = "label7"
        Me.label7.Size = New System.Drawing.Size(16, 20)
        Me.label7.TabIndex = 53
        Me.label7.Text = "��"
        Me.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label6
        '
        Me.label6.Location = New System.Drawing.Point(72, 71)
        Me.label6.Name = "label6"
        Me.label6.Size = New System.Drawing.Size(16, 20)
        Me.label6.TabIndex = 52
        Me.label6.Text = "��"
        Me.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label5
        '
        Me.label5.Location = New System.Drawing.Point(36, 71)
        Me.label5.Name = "label5"
        Me.label5.Size = New System.Drawing.Size(16, 20)
        Me.label5.TabIndex = 51
        Me.label5.Text = "��"
        Me.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtDay
        '
        Me.txtDay.Location = New System.Drawing.Point(88, 69)
        Me.txtDay.Name = "txtDay"
        Me.txtDay.ReadOnly = True
        Me.txtDay.Size = New System.Drawing.Size(20, 21)
        Me.txtDay.TabIndex = 41
        Me.txtDay.TabStop = False
        Me.txtDay.Text = "01"
        '
        'txtMonth
        '
        Me.txtMonth.Location = New System.Drawing.Point(52, 69)
        Me.txtMonth.Name = "txtMonth"
        Me.txtMonth.ReadOnly = True
        Me.txtMonth.Size = New System.Drawing.Size(20, 21)
        Me.txtMonth.TabIndex = 42
        Me.txtMonth.TabStop = False
        Me.txtMonth.Text = "01"
        '
        'txtYear
        '
        Me.txtYear.Location = New System.Drawing.Point(4, 69)
        Me.txtYear.Name = "txtYear"
        Me.txtYear.ReadOnly = True
        Me.txtYear.Size = New System.Drawing.Size(32, 21)
        Me.txtYear.TabIndex = 43
        Me.txtYear.TabStop = False
        Me.txtYear.Text = "2005"
        '
        'txtInvoiceSerialNo
        '
        Me.txtInvoiceSerialNo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtInvoiceSerialNo.Location = New System.Drawing.Point(592, 61)
        Me.txtInvoiceSerialNo.Name = "txtInvoiceSerialNo"
        Me.txtInvoiceSerialNo.Size = New System.Drawing.Size(184, 21)
        Me.txtInvoiceSerialNo.TabIndex = 47
        Me.txtInvoiceSerialNo.Text = ""
        '
        'txtInvoiceCode
        '
        Me.txtInvoiceCode.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtInvoiceCode.Location = New System.Drawing.Point(592, 37)
        Me.txtInvoiceCode.Name = "txtInvoiceCode"
        Me.txtInvoiceCode.Size = New System.Drawing.Size(184, 21)
        Me.txtInvoiceCode.TabIndex = 44
        Me.txtInvoiceCode.Text = ""
        '
        'label4
        '
        Me.label4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.label4.Location = New System.Drawing.Point(528, 65)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(124, 23)
        Me.label4.TabIndex = 49
        Me.label4.Text = "��Ʊ���룺"
        '
        'label3
        '
        Me.label3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.label3.Location = New System.Drawing.Point(528, 41)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(124, 23)
        Me.label3.TabIndex = 48
        Me.label3.Text = "��Ʊ���룺"
        '
        'label2
        '
        Me.label2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.label2.Font = New System.Drawing.Font("����", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.label2.Location = New System.Drawing.Point(8, 31)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(776, 32)
        Me.label2.TabIndex = 46
        Me.label2.Text = "��  ��  ��"
        Me.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label1
        '
        Me.label1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.label1.Font = New System.Drawing.Font("����", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.label1.Location = New System.Drawing.Point(8, 5)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(776, 32)
        Me.label1.TabIndex = 45
        Me.label1.Text = "˰ �� �� �� �� �� ͳ һ �� Ʊ���� ˰��"
        Me.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'frmInvoice
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(6, 14)
        Me.ClientSize = New System.Drawing.Size(792, 542)
        Me.Controls.Add(Me.txtTaxControlCode)
        Me.Controls.Add(Me.txtWriter)
        Me.Controls.Add(Me.txtDay)
        Me.Controls.Add(Me.txtMonth)
        Me.Controls.Add(Me.txtYear)
        Me.Controls.Add(Me.txtInvoiceSerialNo)
        Me.Controls.Add(Me.txtInvoiceCode)
        Me.Controls.Add(Me.cldSelect)
        Me.Controls.Add(Me.btnCasePrint)
        Me.Controls.Add(Me.btnPreview)
        Me.Controls.Add(Me.btnPrint)
        Me.Controls.Add(Me.panel1)
        Me.Controls.Add(Me.btnRefDate)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.label23)
        Me.Controls.Add(Me.label22)
        Me.Controls.Add(Me.label7)
        Me.Controls.Add(Me.label6)
        Me.Controls.Add(Me.label5)
        Me.Controls.Add(Me.label4)
        Me.Controls.Add(Me.label3)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.label1)
        Me.KeyPreview = True
        Me.Name = "frmInvoice"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "������ʡ�����й���˰���[�� �� ͳ һ �� Ʊ���� ˰��]"
        Me.panel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Enum PrintFlag
        CasePrint       '�״�ֻ��ӡû��ӡˢ�Ĳ���
        PrintAll        '��ӡȫ��
        PreviewAll      'Ԥ��ȫ��
    End Enum

    Private Sub Print_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnPreview.Click, btnPrint.Click, btnCasePrint.Click
        Dim btn As Button = CType(sender, Button)

        Select Case btn.Tag.ToString()
            Case "�״�"
                Print(PrintFlag.CasePrint)
            Case "��ӡ"
                Print(PrintFlag.PrintAll)
            Case "Ԥ��"
                Print(PrintFlag.PreviewAll)
        End Select
    End Sub

    '�״򡢴�ӡԤ��ʵ��
    Private Sub Print(ByVal p_printFlag As PrintFlag)

        '�������裺
        '/*	1����Excel������Ҫ��ӡ����ʽһ���ĵ��ӱ����Ϊģ�壻
        ' *     ���ɣ���ðѵ�һ�����һ����Ϊ���У������ڵ����߾ࣨ��ȻExcel����ӡ���ɵ���ҳ�߾ࣩ�� ����������Ҫ�����ĵط���ռ����뼸�У������ڵ����״��׼
        ' * 
        ' *  2����ͬ������һ������Excel��Ϊ�״��ģ�壬ֱ�ӽ�Ҫ��ӡ������д�룻
        ' * 
        ' *  3����ӡ������ʵ�ʵ�Ч������Excelģ���и��п����ճ������У� ֱ���ܹ�׼ȷ�����ϡ���ģ�忽��һ�ݣ����ģ���ϵ�����Ҳ�����ߣ������״��ģ�塣
        ' */

        '��Excel��ӡ������Ϊ���򿪡�д���ݡ���ӡԤ�����ر�
        Dim excel As New GoldPrinter.ExcelAccess
        Dim strFileName As String = "invoice.xlt"   'ģ���ļ���

        If (p_printFlag = PrintFlag.CasePrint) Then
            strFileName = "invoiceCase.xlt"         '�״�ģ���ļ���
        End If
        Dim strExcelTemplateFile As String = System.IO.Path.GetFullPath("..\ExcelTemplate\" + strFileName)

        excel.Open(strExcelTemplateFile)            '��ģ���ļ�
        excel.IsVisibledExcel = True
        excel.FormCaption = "˰ �� �� �� �� �� ͳ һ �� Ʊ���� ˰��" '"MIS���ʴ�ӡͨ  ͨ�����±���"


        '��ģ����д��Ҫ��ӡ������

        '***��Ʊ̧ͷ***

        '������
        excel.SetCellText(7, "B", txtYear.Text + "��" + txtMonth.Text + "��" + txtDay.Text + "��")

        '�������	
        excel.SetCellText(8, "D", txtPayer.Text)
        '�տ����	
        excel.SetCellText(9, "D", txtCollecter.Text)
        '����ַ���绰	
        excel.SetCellText(11, "D", txtCollecterAddTel.Text)


        ' ������ͨ��Ʊ    �� �� �� �� ��	
        excel.SetCellText(8, "J", txtInvoiceApplicationNo.Text)
        '�տʶ��Ż� ֤ �� �� ��	
        excel.SetCellText(9, "J", txtCollecterID.Text)


        '***Ʒ��������ע***
        'B14��B23��Ʒ��   F14��F23Ϊ���

        excel.SetCellText(14, "B", txtP1.Text)
        excel.SetCellText(14, "F", txtJ1.Text)

        excel.SetCellText(15, "B", txtP2.Text)
        excel.SetCellText(15, "F", txtJ2.Text)

        excel.SetCellText(16, "B", txtP3.Text)
        excel.SetCellText(16, "F", txtJ3.Text)

        excel.SetCellText(17, "B", txtP4.Text)
        excel.SetCellText(17, "F", txtJ4.Text)

        excel.SetCellText(18, "B", txtP5.Text)
        excel.SetCellText(18, "F", txtJ5.Text)

        excel.SetCellText(19, "B", txtP6.Text)
        excel.SetCellText(19, "F", txtJ6.Text)

        excel.SetCellText(20, "B", txtP7.Text)
        excel.SetCellText(20, "F", txtJ7.Text)

        excel.SetCellText(21, "B", txtP8.Text)
        excel.SetCellText(21, "F", txtJ8.Text)

        excel.SetCellText(22, "B", txtP9.Text)
        excel.SetCellText(22, "F", txtJ9.Text)

        excel.SetCellText(23, "B", txtP10.Text)
        excel.SetCellText(23, "F", txtJ10.Text)


        '��ע
        excel.SetCellText(14, "I", txtMemo.Text)



        '***��Ʊ�ܽ��***

        '�ϼ������   ����д��		
        excel.SetCellText(24, "D", txtTotalUpper.Text)
        '�ϼ������   ��Сд��
        excel.SetCellText(24, "K", txtTotalLower.Text)


        '˰��   ����д��	
        excel.SetCellText(25, "D", txtTaxUpper.Text)
        '˰��   ��Сд��	
        excel.SetCellText(25, "L", txtTaxLower.Text)


        '***��Ʊβ***
        '˰����
        excel.SetCellText(26, "C", txtTaxControlCode.Text)
        '��Ʊ�ˣ�	
        excel.SetCellText(26, "H", txtWriter.Text)



        If (p_printFlag = PrintFlag.CasePrint Or p_printFlag = PrintFlag.PrintAll) Then
            excel.Print()           '��ӡ
        Else
            excel.PrintPreview()    'Ԥ��
        End If
        excel.Close()               '�رղ��ͷ�	

    End Sub


    Private Sub frmInvoice_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '��ʼ��������
        Dim dt As System.DateTime = System.DateTime.Now
        SetToday(dt)
    End Sub

    Private Sub btnExit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub


    '�س�
    Private Sub frmInvoice_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles MyBase.KeyPress
        If (e.KeyChar = vbCr) Then
            SendKeys.Send("{TAB}")
        End If

    End Sub


    '���Сдת����Ҵ�д
    Private Sub txtTotalLower_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtTotalLower.KeyUp
        SetUpperMoney()
    End Sub


    '�����ܼ�
    Private Sub txtJX_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtJ1.TextChanged, txtJ2.TextChanged, txtJ3.TextChanged, txtJ4.TextChanged, txtJ5.TextChanged, txtJ6.TextChanged, txtJ7.TextChanged, txtJ8.TextChanged, txtJ9.TextChanged, txtJ10.TextChanged
        Dim dblMoney As Double = 0

        dblMoney += GetInputMoney(txtJ1.Text)
        dblMoney += GetInputMoney(txtJ2.Text)
        dblMoney += GetInputMoney(txtJ3.Text)
        dblMoney += GetInputMoney(txtJ4.Text)
        dblMoney += GetInputMoney(txtJ5.Text)
        dblMoney += GetInputMoney(txtJ6.Text)
        dblMoney += GetInputMoney(txtJ7.Text)
        dblMoney += GetInputMoney(txtJ8.Text)
        dblMoney += GetInputMoney(txtJ9.Text)
        dblMoney += GetInputMoney(txtJ10.Text)

        txtTotalLower.Text = dblMoney.ToString()
        SetUpperMoney()

    End Sub


    '�ı�˰������
    Private Sub cboTaxRate_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboTaxRate.TextChanged
        SetUpperMoney()
    End Sub

    Private Sub btnRefDate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRefDate.Click
        cldSelect.Visible = True
        cldSelect.SetDate(New DateTime(Int32.Parse(txtYear.Text), Int32.Parse(txtMonth.Text), Int32.Parse(txtDay.Text)))
        cldSelect.Focus()
    End Sub

    Private Sub cldSelect_DateSelected(ByVal sender As Object, ByVal e As System.Windows.Forms.DateRangeEventArgs) Handles cldSelect.DateSelected
        SetToday(e.End)
        cldSelect.Visible = False
    End Sub

    '��д�ϼ�����ҡ�˰��
    Private Sub SetUpperMoney()
        Try
            Dim strUpper As String
            strUpper = GoldPrinter.ChineseNum.GetUpperMoney(Double.Parse(txtTotalLower.Text))
            '�ϼ������
            txtTotalUpper.Text = strUpper

            strUpper = GoldPrinter.ChineseNum.GetUpperMoney(Double.Parse(txtTotalLower.Text) * Double.Parse(cboTaxRate.Text) / 100)

            '˰�� = �ϼ������ * ˰��
            txtTaxUpper.Text = strUpper
        Catch ex As Exception

        End Try
    End Sub

    Private Function GetInputMoney(ByVal p_text As String) As Double

        Dim dblReturn As Double = 0
        Try
            dblReturn = Double.Parse(p_text)
        Catch ex As Exception

        End Try

        Return dblReturn

    End Function

    Private Sub SetToday(ByVal dt As System.DateTime)
        txtYear.Text = dt.Year.ToString()

        txtMonth.Text = GetLengthTwoDate(dt.Month.ToString())
        txtDay.Text = GetLengthTwoDate(dt.Day.ToString())

    End Sub

    Private Function GetLengthTwoDate(ByVal p_MonthOrDay As String) As String
        Dim strReturn As String = p_MonthOrDay
        If (strReturn.Length = 1) Then
            strReturn = "0" + strReturn
        End If

        Return strReturn
    End Function


End Class
