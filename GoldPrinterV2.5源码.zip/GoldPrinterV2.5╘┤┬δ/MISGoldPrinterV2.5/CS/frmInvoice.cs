using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace MisGoldPrinterTest
{
	/// <summary>
	/// �״򾭵�����
	/// </summary>
	public class frmInvoice : System.Windows.Forms.Form
	{
		#region Windows ������������ɵĴ���

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox txtInvoiceCode;
		private System.Windows.Forms.TextBox txtInvoiceSerialNo;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.TextBox txtYear;
		private System.Windows.Forms.TextBox txtMonth;
		private System.Windows.Forms.TextBox txtDay;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.Label label17;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Label label29;
		private System.Windows.Forms.Label label30;
		private System.Windows.Forms.Label label31;
		private System.Windows.Forms.Label label32;
		private System.Windows.Forms.Label label33;
		private System.Windows.Forms.Label label34;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.Label label18;
		private System.Windows.Forms.Label label19;
		private System.Windows.Forms.Label label20;
		private System.Windows.Forms.Label label21;
		private System.Windows.Forms.Label label22;
		private System.Windows.Forms.Label label23;
		private System.Windows.Forms.TextBox txtPayer;
		private System.Windows.Forms.TextBox txtCollecter;
		private System.Windows.Forms.TextBox txtCollecterAddTel;
		private System.Windows.Forms.TextBox txtInvoiceApplicationNo;
		private System.Windows.Forms.TextBox txtCollecterID;
		private System.Windows.Forms.TextBox txtMemo;
		private System.Windows.Forms.TextBox txtP1;
		private System.Windows.Forms.TextBox txtJ1;
		private System.Windows.Forms.TextBox txtJ2;
		private System.Windows.Forms.TextBox txtP2;
		private System.Windows.Forms.TextBox txtJ4;
		private System.Windows.Forms.TextBox txtP4;
		private System.Windows.Forms.TextBox txtJ3;
		private System.Windows.Forms.TextBox txtP3;
		private System.Windows.Forms.TextBox txtJ8;
		private System.Windows.Forms.TextBox txtP8;
		private System.Windows.Forms.TextBox txtJ7;
		private System.Windows.Forms.TextBox txtP7;
		private System.Windows.Forms.TextBox txtJ6;
		private System.Windows.Forms.TextBox txtP6;
		private System.Windows.Forms.TextBox txtJ5;
		private System.Windows.Forms.TextBox txtP5;
		private System.Windows.Forms.TextBox txtJ10;
		private System.Windows.Forms.TextBox txtP10;
		private System.Windows.Forms.TextBox txtJ9;
		private System.Windows.Forms.TextBox txtP9;
		private System.Windows.Forms.TextBox txtTotalUpper;
		private System.Windows.Forms.TextBox txtTotalLower;
		private System.Windows.Forms.TextBox txtTaxUpper;
		private System.Windows.Forms.TextBox txtTaxLower;
		private System.Windows.Forms.TextBox txtTaxControlCode;
		private System.Windows.Forms.TextBox txtWriter;
		private System.Windows.Forms.Button btnExit;
		private System.Windows.Forms.Button btnPrint;
		private System.Windows.Forms.Button btnPreview;
		private System.Windows.Forms.Button btnCasePrint;
		private System.Windows.Forms.Button btnRefDate;
		private System.Windows.Forms.MonthCalendar cldSelect;
		private System.Windows.Forms.ComboBox cboTaxRate;
		private System.Windows.Forms.Label label24;
		/// <summary>
		/// ����������������
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmInvoice()
		{
			//
			// Windows ���������֧���������
			//
			InitializeComponent();

			//
			// TODO: �� InitializeComponent ���ú������κι��캯������
			//
		}

		/// <summary>
		/// ������������ʹ�õ���Դ��
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		/// <summary>
		/// �����֧������ķ��� - ��Ҫʹ�ô���༭���޸�
		/// �˷��������ݡ�
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.txtInvoiceCode = new System.Windows.Forms.TextBox();
			this.txtInvoiceSerialNo = new System.Windows.Forms.TextBox();
			this.panel1 = new System.Windows.Forms.Panel();
			this.cboTaxRate = new System.Windows.Forms.ComboBox();
			this.label24 = new System.Windows.Forms.Label();
			this.txtTaxLower = new System.Windows.Forms.TextBox();
			this.txtTotalLower = new System.Windows.Forms.TextBox();
			this.label20 = new System.Windows.Forms.Label();
			this.label21 = new System.Windows.Forms.Label();
			this.label19 = new System.Windows.Forms.Label();
			this.txtTaxUpper = new System.Windows.Forms.TextBox();
			this.label18 = new System.Windows.Forms.Label();
			this.txtTotalUpper = new System.Windows.Forms.TextBox();
			this.label16 = new System.Windows.Forms.Label();
			this.label15 = new System.Windows.Forms.Label();
			this.label14 = new System.Windows.Forms.Label();
			this.txtMemo = new System.Windows.Forms.TextBox();
			this.txtJ10 = new System.Windows.Forms.TextBox();
			this.txtP10 = new System.Windows.Forms.TextBox();
			this.txtJ9 = new System.Windows.Forms.TextBox();
			this.txtP9 = new System.Windows.Forms.TextBox();
			this.txtJ8 = new System.Windows.Forms.TextBox();
			this.txtP8 = new System.Windows.Forms.TextBox();
			this.txtJ7 = new System.Windows.Forms.TextBox();
			this.txtP7 = new System.Windows.Forms.TextBox();
			this.txtJ6 = new System.Windows.Forms.TextBox();
			this.txtP6 = new System.Windows.Forms.TextBox();
			this.txtJ5 = new System.Windows.Forms.TextBox();
			this.txtP5 = new System.Windows.Forms.TextBox();
			this.txtJ4 = new System.Windows.Forms.TextBox();
			this.txtP4 = new System.Windows.Forms.TextBox();
			this.txtJ3 = new System.Windows.Forms.TextBox();
			this.txtP3 = new System.Windows.Forms.TextBox();
			this.txtJ2 = new System.Windows.Forms.TextBox();
			this.txtP2 = new System.Windows.Forms.TextBox();
			this.txtJ1 = new System.Windows.Forms.TextBox();
			this.txtP1 = new System.Windows.Forms.TextBox();
			this.label34 = new System.Windows.Forms.Label();
			this.label33 = new System.Windows.Forms.Label();
			this.txtCollecterID = new System.Windows.Forms.TextBox();
			this.txtInvoiceApplicationNo = new System.Windows.Forms.TextBox();
			this.label31 = new System.Windows.Forms.Label();
			this.label32 = new System.Windows.Forms.Label();
			this.label29 = new System.Windows.Forms.Label();
			this.label30 = new System.Windows.Forms.Label();
			this.txtCollecterAddTel = new System.Windows.Forms.TextBox();
			this.txtCollecter = new System.Windows.Forms.TextBox();
			this.txtPayer = new System.Windows.Forms.TextBox();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.label17 = new System.Windows.Forms.Label();
			this.label13 = new System.Windows.Forms.Label();
			this.label12 = new System.Windows.Forms.Label();
			this.label11 = new System.Windows.Forms.Label();
			this.label10 = new System.Windows.Forms.Label();
			this.label9 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.txtYear = new System.Windows.Forms.TextBox();
			this.txtMonth = new System.Windows.Forms.TextBox();
			this.txtDay = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.label22 = new System.Windows.Forms.Label();
			this.label23 = new System.Windows.Forms.Label();
			this.txtTaxControlCode = new System.Windows.Forms.TextBox();
			this.txtWriter = new System.Windows.Forms.TextBox();
			this.btnPrint = new System.Windows.Forms.Button();
			this.btnPreview = new System.Windows.Forms.Button();
			this.btnExit = new System.Windows.Forms.Button();
			this.btnCasePrint = new System.Windows.Forms.Button();
			this.btnRefDate = new System.Windows.Forms.Button();
			this.cldSelect = new System.Windows.Forms.MonthCalendar();
			this.panel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.label1.Font = new System.Drawing.Font("����", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(134)));
			this.label1.Location = new System.Drawing.Point(8, 2);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(776, 32);
			this.label1.TabIndex = 0;
			this.label1.Text = "˰ �� �� �� �� �� ͳ һ �� Ʊ���� ˰��";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label2
			// 
			this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.label2.Font = new System.Drawing.Font("����", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(134)));
			this.label2.Location = new System.Drawing.Point(8, 28);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(776, 32);
			this.label2.TabIndex = 1;
			this.label2.Text = "��  ��  ��";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label3
			// 
			this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.label3.Location = new System.Drawing.Point(528, 38);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(124, 23);
			this.label3.TabIndex = 2;
			this.label3.Text = "��Ʊ���룺";
			// 
			// label4
			// 
			this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.label4.Location = new System.Drawing.Point(528, 62);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(124, 23);
			this.label4.TabIndex = 3;
			this.label4.Text = "��Ʊ���룺";
			// 
			// txtInvoiceCode
			// 
			this.txtInvoiceCode.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.txtInvoiceCode.Location = new System.Drawing.Point(592, 34);
			this.txtInvoiceCode.Name = "txtInvoiceCode";
			this.txtInvoiceCode.Size = new System.Drawing.Size(184, 21);
			this.txtInvoiceCode.TabIndex = 0;
			this.txtInvoiceCode.Text = "";
			// 
			// txtInvoiceSerialNo
			// 
			this.txtInvoiceSerialNo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.txtInvoiceSerialNo.Location = new System.Drawing.Point(592, 58);
			this.txtInvoiceSerialNo.Name = "txtInvoiceSerialNo";
			this.txtInvoiceSerialNo.Size = new System.Drawing.Size(184, 21);
			this.txtInvoiceSerialNo.TabIndex = 1;
			this.txtInvoiceSerialNo.Text = "";
			// 
			// panel1
			// 
			this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.panel1.Controls.Add(this.cboTaxRate);
			this.panel1.Controls.Add(this.label24);
			this.panel1.Controls.Add(this.txtTaxLower);
			this.panel1.Controls.Add(this.txtTotalLower);
			this.panel1.Controls.Add(this.label20);
			this.panel1.Controls.Add(this.label21);
			this.panel1.Controls.Add(this.label19);
			this.panel1.Controls.Add(this.txtTaxUpper);
			this.panel1.Controls.Add(this.label18);
			this.panel1.Controls.Add(this.txtTotalUpper);
			this.panel1.Controls.Add(this.label16);
			this.panel1.Controls.Add(this.label15);
			this.panel1.Controls.Add(this.label14);
			this.panel1.Controls.Add(this.txtMemo);
			this.panel1.Controls.Add(this.txtJ10);
			this.panel1.Controls.Add(this.txtP10);
			this.panel1.Controls.Add(this.txtJ9);
			this.panel1.Controls.Add(this.txtP9);
			this.panel1.Controls.Add(this.txtJ8);
			this.panel1.Controls.Add(this.txtP8);
			this.panel1.Controls.Add(this.txtJ7);
			this.panel1.Controls.Add(this.txtP7);
			this.panel1.Controls.Add(this.txtJ6);
			this.panel1.Controls.Add(this.txtP6);
			this.panel1.Controls.Add(this.txtJ5);
			this.panel1.Controls.Add(this.txtP5);
			this.panel1.Controls.Add(this.txtJ4);
			this.panel1.Controls.Add(this.txtP4);
			this.panel1.Controls.Add(this.txtJ3);
			this.panel1.Controls.Add(this.txtP3);
			this.panel1.Controls.Add(this.txtJ2);
			this.panel1.Controls.Add(this.txtP2);
			this.panel1.Controls.Add(this.txtJ1);
			this.panel1.Controls.Add(this.txtP1);
			this.panel1.Controls.Add(this.label34);
			this.panel1.Controls.Add(this.label33);
			this.panel1.Controls.Add(this.txtCollecterID);
			this.panel1.Controls.Add(this.txtInvoiceApplicationNo);
			this.panel1.Controls.Add(this.label31);
			this.panel1.Controls.Add(this.label32);
			this.panel1.Controls.Add(this.label29);
			this.panel1.Controls.Add(this.label30);
			this.panel1.Controls.Add(this.txtCollecterAddTel);
			this.panel1.Controls.Add(this.txtCollecter);
			this.panel1.Controls.Add(this.txtPayer);
			this.panel1.Controls.Add(this.pictureBox1);
			this.panel1.Controls.Add(this.label17);
			this.panel1.Controls.Add(this.label13);
			this.panel1.Controls.Add(this.label12);
			this.panel1.Controls.Add(this.label11);
			this.panel1.Controls.Add(this.label10);
			this.panel1.Controls.Add(this.label9);
			this.panel1.Controls.Add(this.label8);
			this.panel1.Location = new System.Drawing.Point(4, 92);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(784, 390);
			this.panel1.TabIndex = 6;
			// 
			// cboTaxRate
			// 
			this.cboTaxRate.Items.AddRange(new object[] {
															"7",
															"13",
															"15",
															"17"});
			this.cboTaxRate.Location = new System.Drawing.Point(616, 306);
			this.cboTaxRate.Name = "cboTaxRate";
			this.cboTaxRate.Size = new System.Drawing.Size(52, 20);
			this.cboTaxRate.TabIndex = 27;
			this.cboTaxRate.TabStop = false;
			this.cboTaxRate.Text = "7";
			this.cboTaxRate.TextChanged += new System.EventHandler(this.cboTaxRate_TextChanged);
			// 
			// label24
			// 
			this.label24.Location = new System.Drawing.Point(538, 306);
			this.label24.Name = "label24";
			this.label24.Size = new System.Drawing.Size(88, 22);
			this.label24.TabIndex = 68;
			this.label24.Text = "˰������(%)��";
			this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// txtTaxLower
			// 
			this.txtTaxLower.Location = new System.Drawing.Point(618, 362);
			this.txtTaxLower.Name = "txtTaxLower";
			this.txtTaxLower.Size = new System.Drawing.Size(158, 21);
			this.txtTaxLower.TabIndex = 31;
			this.txtTaxLower.Text = "";
			// 
			// txtTotalLower
			// 
			this.txtTotalLower.Location = new System.Drawing.Point(618, 336);
			this.txtTotalLower.Name = "txtTotalLower";
			this.txtTotalLower.Size = new System.Drawing.Size(158, 21);
			this.txtTotalLower.TabIndex = 29;
			this.txtTotalLower.Text = "";
			this.txtTotalLower.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtTotalLower_KeyUp);
			// 
			// label20
			// 
			this.label20.Location = new System.Drawing.Point(534, 362);
			this.label20.Name = "label20";
			this.label20.Size = new System.Drawing.Size(80, 18);
			this.label20.TabIndex = 63;
			this.label20.Text = "��˰ƾ֤����";
			this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label21
			// 
			this.label21.Location = new System.Drawing.Point(534, 336);
			this.label21.Name = "label21";
			this.label21.Size = new System.Drawing.Size(80, 18);
			this.label21.TabIndex = 62;
			this.label21.Text = "(Сд)";
			this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label19
			// 
			this.label19.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.label19.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label19.Location = new System.Drawing.Point(6, 356);
			this.label19.Name = "label19";
			this.label19.Size = new System.Drawing.Size(768, 3);
			this.label19.TabIndex = 61;
			// 
			// txtTaxUpper
			// 
			this.txtTaxUpper.Location = new System.Drawing.Point(114, 360);
			this.txtTaxUpper.Name = "txtTaxUpper";
			this.txtTaxUpper.Size = new System.Drawing.Size(416, 21);
			this.txtTaxUpper.TabIndex = 30;
			this.txtTaxUpper.Text = "";
			// 
			// label18
			// 
			this.label18.Location = new System.Drawing.Point(6, 362);
			this.label18.Name = "label18";
			this.label18.Size = new System.Drawing.Size(104, 18);
			this.label18.TabIndex = 59;
			this.label18.Text = "˰��(��д)";
			this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// txtTotalUpper
			// 
			this.txtTotalUpper.Location = new System.Drawing.Point(114, 334);
			this.txtTotalUpper.Name = "txtTotalUpper";
			this.txtTotalUpper.Size = new System.Drawing.Size(416, 21);
			this.txtTotalUpper.TabIndex = 28;
			this.txtTotalUpper.Text = "";
			// 
			// label16
			// 
			this.label16.Location = new System.Drawing.Point(6, 336);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(104, 18);
			this.label16.TabIndex = 57;
			this.label16.Text = "�ϼ������(��д)";
			this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label15
			// 
			this.label15.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.label15.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label15.Location = new System.Drawing.Point(6, 328);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(768, 3);
			this.label15.TabIndex = 56;
			// 
			// label14
			// 
			this.label14.Location = new System.Drawing.Point(666, 308);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(102, 18);
			this.label14.TabIndex = 55;
			this.label14.Text = "������λ����";
			this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// txtMemo
			// 
			this.txtMemo.Location = new System.Drawing.Point(538, 126);
			this.txtMemo.Multiline = true;
			this.txtMemo.Name = "txtMemo";
			this.txtMemo.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.txtMemo.Size = new System.Drawing.Size(230, 178);
			this.txtMemo.TabIndex = 27;
			this.txtMemo.Text = "";
			// 
			// txtJ10
			// 
			this.txtJ10.Font = new System.Drawing.Font("����", 8F);
			this.txtJ10.Location = new System.Drawing.Point(440, 304);
			this.txtJ10.Name = "txtJ10";
			this.txtJ10.Size = new System.Drawing.Size(88, 20);
			this.txtJ10.TabIndex = 26;
			this.txtJ10.Text = "";
			this.txtJ10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.txtJ10.TextChanged += new System.EventHandler(this.txtJX_TextChanged);
			// 
			// txtP10
			// 
			this.txtP10.Font = new System.Drawing.Font("����", 8F);
			this.txtP10.Location = new System.Drawing.Point(6, 304);
			this.txtP10.Name = "txtP10";
			this.txtP10.Size = new System.Drawing.Size(430, 20);
			this.txtP10.TabIndex = 25;
			this.txtP10.Text = "";
			// 
			// txtJ9
			// 
			this.txtJ9.Font = new System.Drawing.Font("����", 8F);
			this.txtJ9.Location = new System.Drawing.Point(440, 284);
			this.txtJ9.Name = "txtJ9";
			this.txtJ9.Size = new System.Drawing.Size(88, 20);
			this.txtJ9.TabIndex = 24;
			this.txtJ9.Text = "";
			this.txtJ9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.txtJ9.TextChanged += new System.EventHandler(this.txtJX_TextChanged);
			// 
			// txtP9
			// 
			this.txtP9.Font = new System.Drawing.Font("����", 8F);
			this.txtP9.Location = new System.Drawing.Point(6, 284);
			this.txtP9.Name = "txtP9";
			this.txtP9.Size = new System.Drawing.Size(430, 20);
			this.txtP9.TabIndex = 23;
			this.txtP9.Text = "";
			// 
			// txtJ8
			// 
			this.txtJ8.Font = new System.Drawing.Font("����", 8F);
			this.txtJ8.Location = new System.Drawing.Point(440, 264);
			this.txtJ8.Name = "txtJ8";
			this.txtJ8.Size = new System.Drawing.Size(88, 20);
			this.txtJ8.TabIndex = 22;
			this.txtJ8.Text = "";
			this.txtJ8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.txtJ8.TextChanged += new System.EventHandler(this.txtJX_TextChanged);
			// 
			// txtP8
			// 
			this.txtP8.Font = new System.Drawing.Font("����", 8F);
			this.txtP8.Location = new System.Drawing.Point(6, 264);
			this.txtP8.Name = "txtP8";
			this.txtP8.Size = new System.Drawing.Size(430, 20);
			this.txtP8.TabIndex = 21;
			this.txtP8.Text = "";
			// 
			// txtJ7
			// 
			this.txtJ7.Font = new System.Drawing.Font("����", 8F);
			this.txtJ7.Location = new System.Drawing.Point(440, 244);
			this.txtJ7.Name = "txtJ7";
			this.txtJ7.Size = new System.Drawing.Size(88, 20);
			this.txtJ7.TabIndex = 20;
			this.txtJ7.Text = "";
			this.txtJ7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.txtJ7.TextChanged += new System.EventHandler(this.txtJX_TextChanged);
			// 
			// txtP7
			// 
			this.txtP7.Font = new System.Drawing.Font("����", 8F);
			this.txtP7.Location = new System.Drawing.Point(6, 244);
			this.txtP7.Name = "txtP7";
			this.txtP7.Size = new System.Drawing.Size(430, 20);
			this.txtP7.TabIndex = 19;
			this.txtP7.Text = "";
			// 
			// txtJ6
			// 
			this.txtJ6.Font = new System.Drawing.Font("����", 8F);
			this.txtJ6.Location = new System.Drawing.Point(440, 224);
			this.txtJ6.Name = "txtJ6";
			this.txtJ6.Size = new System.Drawing.Size(88, 20);
			this.txtJ6.TabIndex = 18;
			this.txtJ6.Text = "";
			this.txtJ6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.txtJ6.TextChanged += new System.EventHandler(this.txtJX_TextChanged);
			// 
			// txtP6
			// 
			this.txtP6.Font = new System.Drawing.Font("����", 8F);
			this.txtP6.Location = new System.Drawing.Point(6, 224);
			this.txtP6.Name = "txtP6";
			this.txtP6.Size = new System.Drawing.Size(430, 20);
			this.txtP6.TabIndex = 17;
			this.txtP6.Text = "";
			// 
			// txtJ5
			// 
			this.txtJ5.Font = new System.Drawing.Font("����", 8F);
			this.txtJ5.Location = new System.Drawing.Point(440, 204);
			this.txtJ5.Name = "txtJ5";
			this.txtJ5.Size = new System.Drawing.Size(88, 20);
			this.txtJ5.TabIndex = 16;
			this.txtJ5.Text = "";
			this.txtJ5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.txtJ5.TextChanged += new System.EventHandler(this.txtJX_TextChanged);
			// 
			// txtP5
			// 
			this.txtP5.Font = new System.Drawing.Font("����", 8F);
			this.txtP5.Location = new System.Drawing.Point(6, 204);
			this.txtP5.Name = "txtP5";
			this.txtP5.Size = new System.Drawing.Size(430, 20);
			this.txtP5.TabIndex = 15;
			this.txtP5.Text = "";
			// 
			// txtJ4
			// 
			this.txtJ4.Font = new System.Drawing.Font("����", 8F);
			this.txtJ4.Location = new System.Drawing.Point(440, 184);
			this.txtJ4.Name = "txtJ4";
			this.txtJ4.Size = new System.Drawing.Size(88, 20);
			this.txtJ4.TabIndex = 14;
			this.txtJ4.Text = "";
			this.txtJ4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.txtJ4.TextChanged += new System.EventHandler(this.txtJX_TextChanged);
			// 
			// txtP4
			// 
			this.txtP4.Font = new System.Drawing.Font("����", 8F);
			this.txtP4.Location = new System.Drawing.Point(6, 184);
			this.txtP4.Name = "txtP4";
			this.txtP4.Size = new System.Drawing.Size(430, 20);
			this.txtP4.TabIndex = 13;
			this.txtP4.Text = "";
			// 
			// txtJ3
			// 
			this.txtJ3.Font = new System.Drawing.Font("����", 8F);
			this.txtJ3.Location = new System.Drawing.Point(440, 164);
			this.txtJ3.Name = "txtJ3";
			this.txtJ3.Size = new System.Drawing.Size(88, 20);
			this.txtJ3.TabIndex = 12;
			this.txtJ3.Text = "";
			this.txtJ3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.txtJ3.TextChanged += new System.EventHandler(this.txtJX_TextChanged);
			// 
			// txtP3
			// 
			this.txtP3.Font = new System.Drawing.Font("����", 8F);
			this.txtP3.Location = new System.Drawing.Point(6, 164);
			this.txtP3.Name = "txtP3";
			this.txtP3.Size = new System.Drawing.Size(430, 20);
			this.txtP3.TabIndex = 11;
			this.txtP3.Text = "";
			// 
			// txtJ2
			// 
			this.txtJ2.Font = new System.Drawing.Font("����", 8F);
			this.txtJ2.Location = new System.Drawing.Point(440, 144);
			this.txtJ2.Name = "txtJ2";
			this.txtJ2.Size = new System.Drawing.Size(88, 20);
			this.txtJ2.TabIndex = 10;
			this.txtJ2.Text = "";
			this.txtJ2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.txtJ2.TextChanged += new System.EventHandler(this.txtJX_TextChanged);
			// 
			// txtP2
			// 
			this.txtP2.Font = new System.Drawing.Font("����", 8F);
			this.txtP2.Location = new System.Drawing.Point(6, 144);
			this.txtP2.Name = "txtP2";
			this.txtP2.Size = new System.Drawing.Size(430, 20);
			this.txtP2.TabIndex = 9;
			this.txtP2.Text = "";
			// 
			// txtJ1
			// 
			this.txtJ1.Font = new System.Drawing.Font("����", 8F);
			this.txtJ1.Location = new System.Drawing.Point(440, 124);
			this.txtJ1.Name = "txtJ1";
			this.txtJ1.Size = new System.Drawing.Size(88, 20);
			this.txtJ1.TabIndex = 8;
			this.txtJ1.Text = "";
			this.txtJ1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.txtJ1.TextChanged += new System.EventHandler(this.txtJX_TextChanged);
			// 
			// txtP1
			// 
			this.txtP1.Font = new System.Drawing.Font("����", 8F);
			this.txtP1.Location = new System.Drawing.Point(6, 124);
			this.txtP1.Name = "txtP1";
			this.txtP1.Size = new System.Drawing.Size(430, 20);
			this.txtP1.TabIndex = 7;
			this.txtP1.Text = "";
			// 
			// label34
			// 
			this.label34.Location = new System.Drawing.Point(538, 94);
			this.label34.Name = "label34";
			this.label34.Size = new System.Drawing.Size(230, 22);
			this.label34.TabIndex = 33;
			this.label34.Text = "��           ע";
			this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label33
			// 
			this.label33.Location = new System.Drawing.Point(8, 94);
			this.label33.Name = "label33";
			this.label33.Size = new System.Drawing.Size(520, 22);
			this.label33.TabIndex = 32;
			this.label33.Text = "Ʒ       Ŀ       ��       ��       ��";
			this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// txtCollecterID
			// 
			this.txtCollecterID.Location = new System.Drawing.Point(494, 58);
			this.txtCollecterID.Name = "txtCollecterID";
			this.txtCollecterID.Size = new System.Drawing.Size(282, 21);
			this.txtCollecterID.TabIndex = 6;
			this.txtCollecterID.Text = "";
			// 
			// txtInvoiceApplicationNo
			// 
			this.txtInvoiceApplicationNo.Location = new System.Drawing.Point(494, 18);
			this.txtInvoiceApplicationNo.Name = "txtInvoiceApplicationNo";
			this.txtInvoiceApplicationNo.Size = new System.Drawing.Size(282, 21);
			this.txtInvoiceApplicationNo.TabIndex = 3;
			this.txtInvoiceApplicationNo.Text = "";
			// 
			// label31
			// 
			this.label31.Location = new System.Drawing.Point(398, 70);
			this.label31.Name = "label31";
			this.label31.Size = new System.Drawing.Size(92, 18);
			this.label31.TabIndex = 29;
			this.label31.Text = "�� ֤ �� �� ��";
			this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label32
			// 
			this.label32.Location = new System.Drawing.Point(398, 50);
			this.label32.Name = "label32";
			this.label32.Size = new System.Drawing.Size(92, 18);
			this.label32.TabIndex = 28;
			this.label32.Text = "�տʶ���";
			this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label29
			// 
			this.label29.Location = new System.Drawing.Point(398, 26);
			this.label29.Name = "label29";
			this.label29.Size = new System.Drawing.Size(92, 18);
			this.label29.TabIndex = 27;
			this.label29.Text = "�� �� �� �� ��";
			this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label30
			// 
			this.label30.Location = new System.Drawing.Point(398, 6);
			this.label30.Name = "label30";
			this.label30.Size = new System.Drawing.Size(92, 18);
			this.label30.TabIndex = 26;
			this.label30.Text = "������ͨ��Ʊ";
			this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// txtCollecterAddTel
			// 
			this.txtCollecterAddTel.Location = new System.Drawing.Point(104, 68);
			this.txtCollecterAddTel.Name = "txtCollecterAddTel";
			this.txtCollecterAddTel.Size = new System.Drawing.Size(282, 21);
			this.txtCollecterAddTel.TabIndex = 5;
			this.txtCollecterAddTel.Text = "";
			// 
			// txtCollecter
			// 
			this.txtCollecter.Location = new System.Drawing.Point(104, 48);
			this.txtCollecter.Name = "txtCollecter";
			this.txtCollecter.Size = new System.Drawing.Size(282, 21);
			this.txtCollecter.TabIndex = 4;
			this.txtCollecter.Text = "";
			// 
			// txtPayer
			// 
			this.txtPayer.Location = new System.Drawing.Point(104, 12);
			this.txtPayer.Name = "txtPayer";
			this.txtPayer.Size = new System.Drawing.Size(282, 21);
			this.txtPayer.TabIndex = 2;
			this.txtPayer.Text = "";
			// 
			// pictureBox1
			// 
			this.pictureBox1.Location = new System.Drawing.Point(390, 8);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(3, 80);
			this.pictureBox1.TabIndex = 22;
			this.pictureBox1.TabStop = false;
			// 
			// label17
			// 
			this.label17.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.label17.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label17.Location = new System.Drawing.Point(6, 116);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(768, 3);
			this.label17.TabIndex = 10;
			// 
			// label13
			// 
			this.label13.Location = new System.Drawing.Point(8, 70);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(92, 18);
			this.label13.TabIndex = 6;
			this.label13.Text = "����ַ���绰";
			this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label12
			// 
			this.label12.Location = new System.Drawing.Point(8, 50);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(92, 18);
			this.label12.TabIndex = 5;
			this.label12.Text = "�տ����";
			this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label11
			// 
			this.label11.Location = new System.Drawing.Point(8, 6);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(92, 36);
			this.label11.TabIndex = 4;
			this.label11.Text = "�������";
			this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label10
			// 
			this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.label10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label10.Location = new System.Drawing.Point(6, 88);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(768, 3);
			this.label10.TabIndex = 2;
			this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label9
			// 
			this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.label9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label9.Location = new System.Drawing.Point(6, 44);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(768, 3);
			this.label9.TabIndex = 1;
			// 
			// label8
			// 
			this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.label8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label8.Location = new System.Drawing.Point(4, -10);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(768, 9);
			this.label8.TabIndex = 0;
			// 
			// txtYear
			// 
			this.txtYear.Location = new System.Drawing.Point(4, 66);
			this.txtYear.Name = "txtYear";
			this.txtYear.ReadOnly = true;
			this.txtYear.Size = new System.Drawing.Size(32, 21);
			this.txtYear.TabIndex = 0;
			this.txtYear.TabStop = false;
			this.txtYear.Text = "2005";
			// 
			// txtMonth
			// 
			this.txtMonth.Location = new System.Drawing.Point(52, 66);
			this.txtMonth.Name = "txtMonth";
			this.txtMonth.ReadOnly = true;
			this.txtMonth.Size = new System.Drawing.Size(20, 21);
			this.txtMonth.TabIndex = 0;
			this.txtMonth.TabStop = false;
			this.txtMonth.Text = "01";
			// 
			// txtDay
			// 
			this.txtDay.Location = new System.Drawing.Point(88, 66);
			this.txtDay.Name = "txtDay";
			this.txtDay.ReadOnly = true;
			this.txtDay.Size = new System.Drawing.Size(20, 21);
			this.txtDay.TabIndex = 0;
			this.txtDay.TabStop = false;
			this.txtDay.Text = "01";
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(36, 68);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(16, 20);
			this.label5.TabIndex = 10;
			this.label5.Text = "��";
			this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(72, 68);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(16, 20);
			this.label6.TabIndex = 11;
			this.label6.Text = "��";
			this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label7
			// 
			this.label7.Location = new System.Drawing.Point(112, 68);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(16, 20);
			this.label7.TabIndex = 12;
			this.label7.Text = "��";
			this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label22
			// 
			this.label22.Location = new System.Drawing.Point(6, 486);
			this.label22.Name = "label22";
			this.label22.Size = new System.Drawing.Size(54, 22);
			this.label22.TabIndex = 13;
			this.label22.Text = "˰���룺";
			this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label23
			// 
			this.label23.Location = new System.Drawing.Point(402, 486);
			this.label23.Name = "label23";
			this.label23.Size = new System.Drawing.Size(54, 22);
			this.label23.TabIndex = 14;
			this.label23.Text = "��Ʊ�ˣ�";
			this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// txtTaxControlCode
			// 
			this.txtTaxControlCode.Location = new System.Drawing.Point(62, 486);
			this.txtTaxControlCode.Name = "txtTaxControlCode";
			this.txtTaxControlCode.Size = new System.Drawing.Size(324, 21);
			this.txtTaxControlCode.TabIndex = 32;
			this.txtTaxControlCode.Text = "";
			// 
			// txtWriter
			// 
			this.txtWriter.Location = new System.Drawing.Point(458, 486);
			this.txtWriter.Name = "txtWriter";
			this.txtWriter.Size = new System.Drawing.Size(324, 21);
			this.txtWriter.TabIndex = 33;
			this.txtWriter.Text = "";
			// 
			// btnPrint
			// 
			this.btnPrint.Location = new System.Drawing.Point(480, 512);
			this.btnPrint.Name = "btnPrint";
			this.btnPrint.TabIndex = 35;
			this.btnPrint.Tag = "��ӡ";
			this.btnPrint.Text = "��ӡ(&P)";
			this.btnPrint.Click += new System.EventHandler(this.Print_Click);
			// 
			// btnPreview
			// 
			this.btnPreview.Location = new System.Drawing.Point(562, 512);
			this.btnPreview.Name = "btnPreview";
			this.btnPreview.TabIndex = 36;
			this.btnPreview.Tag = "Ԥ��";
			this.btnPreview.Text = "Ԥ��(&V)";
			this.btnPreview.Click += new System.EventHandler(this.Print_Click);
			// 
			// btnExit
			// 
			this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnExit.Location = new System.Drawing.Point(708, 512);
			this.btnExit.Name = "btnExit";
			this.btnExit.TabIndex = 37;
			this.btnExit.Text = "�˳�(&X)";
			this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
			// 
			// btnCasePrint
			// 
			this.btnCasePrint.Location = new System.Drawing.Point(400, 512);
			this.btnCasePrint.Name = "btnCasePrint";
			this.btnCasePrint.TabIndex = 34;
			this.btnCasePrint.Tag = "�״�";
			this.btnCasePrint.Text = "�״�(&T)";
			this.btnCasePrint.Click += new System.EventHandler(this.Print_Click);
			// 
			// btnRefDate
			// 
			this.btnRefDate.Location = new System.Drawing.Point(134, 66);
			this.btnRefDate.Name = "btnRefDate";
			this.btnRefDate.Size = new System.Drawing.Size(32, 23);
			this.btnRefDate.TabIndex = 0;
			this.btnRefDate.TabStop = false;
			this.btnRefDate.Text = "...";
			this.btnRefDate.Click += new System.EventHandler(this.btnRefDate_Click);
			// 
			// cldSelect
			// 
			this.cldSelect.Location = new System.Drawing.Point(169, 67);
			this.cldSelect.MaxDate = new System.DateTime(2999, 12, 31, 0, 0, 0, 0);
			this.cldSelect.MaxSelectionCount = 1;
			this.cldSelect.MinDate = new System.DateTime(1949, 1, 1, 0, 0, 0, 0);
			this.cldSelect.Name = "cldSelect";
			this.cldSelect.TabIndex = 39;
			this.cldSelect.TabStop = false;
			this.cldSelect.Visible = false;
			this.cldSelect.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.cldSelect_DateSelected);
			// 
			// frmInvoice
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(6, 14);
			this.CancelButton = this.btnExit;
			this.ClientSize = new System.Drawing.Size(792, 542);
			this.Controls.Add(this.cldSelect);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.btnRefDate);
			this.Controls.Add(this.btnCasePrint);
			this.Controls.Add(this.btnExit);
			this.Controls.Add(this.btnPreview);
			this.Controls.Add(this.btnPrint);
			this.Controls.Add(this.txtWriter);
			this.Controls.Add(this.txtTaxControlCode);
			this.Controls.Add(this.label23);
			this.Controls.Add(this.label22);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.txtDay);
			this.Controls.Add(this.txtMonth);
			this.Controls.Add(this.txtYear);
			this.Controls.Add(this.txtInvoiceSerialNo);
			this.Controls.Add(this.txtInvoiceCode);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.KeyPreview = true;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "frmInvoice";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "������ʡ�����й���˰���[�� �� ͳ һ �� Ʊ���� ˰��]";
			this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.frmInvoice_KeyPress);
			this.Load += new System.EventHandler(this.frmInvoice_Load);
			this.panel1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion


		//��ӡ������״򡢴�ӡ��Ԥ��
		enum PrintFlag
		{
			/// <summary>
			/// �״�ֻ��ӡû��ӡˢ�Ĳ���
			/// </summary>
			CasePrint,

			/// <summary>
			/// ��ӡȫ��
			/// </summary>
			PrintAll,

			/// <summary>
			/// Ԥ��ȫ��
			/// </summary>
			PreviewAll		
		}

		private void frmInvoice_Load(object sender, System.EventArgs e)
		{
			//��ʼ��������
			System.DateTime dt = System.DateTime.Now;
			SetToday(dt);
		}


		private void btnExit_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void Print_Click(object sender, System.EventArgs e)
		{
			Button btn = (Button)sender;
			switch(btn.Tag.ToString())
			{
				case "�״�":
					Print(PrintFlag.CasePrint);
					break;
				case "��ӡ":
					Print(PrintFlag.PrintAll);
					break;
				case "Ԥ��":
					Print(PrintFlag.PreviewAll);
					break;			
			}		
		}

		private void Print(PrintFlag p_printFlag)
		{

			//�������裺
			/*	1����Excel������Ҫ��ӡ����ʽһ���ĵ��ӱ����Ϊģ�壻
			 *     ���ɣ���ðѵ�һ�����һ����Ϊ���У������ڵ����߾ࣨ��ȻExcel����ӡ���ɵ���ҳ�߾ࣩ�� ����������Ҫ�����ĵط���ռ����뼸�У������ڵ����״��׼
			 * 
			 *  2����ͬ������һ������Excel��Ϊ�״��ģ�壬ֱ�ӽ�Ҫ��ӡ������д�룻
			 * 
			 *  3����ӡ������ʵ�ʵ�Ч������Excelģ���и��п����ճ������У� ֱ���ܹ�׼ȷ�����ϡ���ģ�忽��һ�ݣ����ģ���ϵ�����Ҳ�����ߣ������״��ģ�塣
			 */

			#region �״򡢴�ӡԤ��

			//��Excel��ӡ������Ϊ���򿪡�д���ݡ���ӡԤ�����ر�
			GoldPrinter.ExcelAccess excel = new GoldPrinter.ExcelAccess();	
			string strFileName = "invoice.xlt";			//ģ���ļ���

			if (p_printFlag == PrintFlag.CasePrint)
			{
				strFileName = "invoiceCase.xlt";		//�״�ģ���ļ���
			}

			string strExcelTemplateFile = System.IO.Path.GetFullPath(@"..\..\ExcelTemplate\" + strFileName);
						
			excel.Open(strExcelTemplateFile);								//��ģ���ļ�
			excel.IsVisibledExcel = true;
			excel.FormCaption = "˰ �� �� �� �� �� ͳ һ �� Ʊ���� ˰��";	//"MIS���ʴ�ӡͨ  ͨ�����±���";


			//��ģ����д��Ҫ��ӡ������

			//***��Ʊ̧ͷ***

			//������
			excel.SetCellText(7,"B",txtYear.Text + "��" + txtMonth.Text + "��" + txtDay.Text + "��" );	
			
			//�������	
			excel.SetCellText(8,"D",txtPayer.Text);
			//�տ����	
			excel.SetCellText(9,"D",txtCollecter.Text);
			//����ַ���绰	
			excel.SetCellText(11,"D",txtCollecterAddTel.Text);


			// ������ͨ��Ʊ    �� �� �� �� ��	
			excel.SetCellText(8,"J",txtInvoiceApplicationNo.Text);
			//�տʶ��Ż� ֤ �� �� ��	
			excel.SetCellText(9,"J",txtCollecterID.Text);

			
			//***Ʒ��������ע***
			//B14��B23��Ʒ��   F14��F23Ϊ���

			excel.SetCellText(14,"B",txtP1.Text);
			excel.SetCellText(14,"F",txtJ1.Text);
			
			excel.SetCellText(15,"B",txtP2.Text);
			excel.SetCellText(15,"F",txtJ2.Text);

			excel.SetCellText(16,"B",txtP3.Text);
			excel.SetCellText(16,"F",txtJ3.Text);

			excel.SetCellText(17,"B",txtP4.Text);
			excel.SetCellText(17,"F",txtJ4.Text);

			excel.SetCellText(18,"B",txtP5.Text);
			excel.SetCellText(18,"F",txtJ5.Text);

			excel.SetCellText(19,"B",txtP6.Text);
			excel.SetCellText(19,"F",txtJ6.Text);

			excel.SetCellText(20,"B",txtP7.Text);
			excel.SetCellText(20,"F",txtJ7.Text);

			excel.SetCellText(21,"B",txtP8.Text);
			excel.SetCellText(21,"F",txtJ8.Text);

			excel.SetCellText(22,"B",txtP9.Text);
			excel.SetCellText(22,"F",txtJ9.Text);

			excel.SetCellText(23,"B",txtP10.Text);
			excel.SetCellText(23,"F",txtJ10.Text);


			//��ע
			excel.SetCellText(14,"I",txtMemo.Text);



			//***��Ʊ�ܽ��***

			//�ϼ������   ����д��		
			excel.SetCellText(24,"D",txtTotalUpper.Text);
			//�ϼ������   ��Сд��
			excel.SetCellText(24,"K",txtTotalLower.Text);


			//˰��   ����д��	
			excel.SetCellText(25,"D",txtTaxUpper.Text);
			//˰��   ��Сд��	
			excel.SetCellText(25,"L",txtTaxLower.Text);


			//***��Ʊβ***
			//˰����
			excel.SetCellText(26,"C",txtTaxControlCode.Text);
			//��Ʊ�ˣ�	
			excel.SetCellText(26,"H",txtWriter.Text);



			if (p_printFlag == PrintFlag.CasePrint || p_printFlag == PrintFlag.PrintAll)
			{
				excel.Print();				//��ӡ
			}
			else
			{
				excel.PrintPreview();		//Ԥ��
			}

			excel.Close();					//�رղ��ͷ�	
			
			#endregion
	
		}


		//�س�
		private void frmInvoice_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			if (e.KeyChar == (char)13)
			{
				SendKeys.Send("{TAB}");
			}
		}

		//���Сдת����Ҵ�д
		private void txtTotalLower_KeyUp(object sender, System.Windows.Forms.KeyEventArgs e)
		{
			SetUpperMoney();
		}


		//�����ܼ�
		private void txtJX_TextChanged(object sender, System.EventArgs e)
		{
			double dblMoney = 0;

			dblMoney += GetInputMoney(txtJ1.Text);
			dblMoney += GetInputMoney(txtJ2.Text);
			dblMoney += GetInputMoney(txtJ3.Text);
			dblMoney += GetInputMoney(txtJ4.Text);
			dblMoney += GetInputMoney(txtJ5.Text);
			dblMoney += GetInputMoney(txtJ6.Text);
			dblMoney += GetInputMoney(txtJ7.Text);
			dblMoney += GetInputMoney(txtJ8.Text);
			dblMoney += GetInputMoney(txtJ9.Text);
			dblMoney += GetInputMoney(txtJ10.Text);

			txtTotalLower.Text = dblMoney.ToString();
			SetUpperMoney();

		}

		//�ı�˰������
		private void cboTaxRate_TextChanged(object sender, System.EventArgs e)
		{
			SetUpperMoney();
		}

		private void btnRefDate_Click(object sender, System.EventArgs e)
		{
			cldSelect.Visible = true;
			cldSelect.SetDate(new DateTime(int.Parse(txtYear.Text),int.Parse(txtMonth.Text),int.Parse(txtDay.Text)));
			cldSelect.Focus();
		}

		private void cldSelect_DateSelected(object sender, System.Windows.Forms.DateRangeEventArgs e)
		{
			SetToday(e.End);
			cldSelect.Visible = false;		
		}





		//��д�ϼ�����ҡ�˰��
		private void SetUpperMoney()
		{
			try
			{
				string strUpper = GoldPrinter.ChineseNum.GetUpperMoney(Double.Parse(txtTotalLower.Text));
				//�ϼ������
				txtTotalUpper.Text = strUpper;

				strUpper = GoldPrinter.ChineseNum.GetUpperMoney(Double.Parse(txtTotalLower.Text) * Double.Parse(cboTaxRate.Text) / 100);
				//˰�� = �ϼ������ * ˰��
				txtTaxUpper.Text = strUpper;

			}
			catch{}				
		}

		private double GetInputMoney(string p_text)
		{
			double dblReturn = 0;
			try
			{
				dblReturn = double.Parse(p_text);
			}
			catch{}

			return dblReturn;
		}

		private void SetToday(System.DateTime dt)
		{
			txtYear.Text = dt.Year.ToString();	
			
			txtMonth.Text = GetLengthTwoDate(dt.Month.ToString());
			txtDay.Text = GetLengthTwoDate(dt.Day.ToString());	
		}

		private string GetLengthTwoDate(string p_MonthOrDay)
		{
			string strReturn = p_MonthOrDay;
			if (strReturn.Length == 1)
			{
				strReturn = "0" + strReturn;
			}

			return strReturn;
		}


	}//End Class
}//End Namespace

