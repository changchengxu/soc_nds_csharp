using System;
using System.Data;

namespace MisGoldPrinterTest
{
	/// <summary>
	/// Ϊ��ӡ�ṩ��������
	/// </summary>
	public class PrintDataSource
	{
		public static DataTable GetDataSource(int p_DataRows)
		{
			DataTable dt = new DataTable();

			int rows = p_DataRows;
			int cols = 6;

			//������
			for (int intRowIndex=0;intRowIndex<rows;intRowIndex++)
			{
				dt.Rows.Add(dt.NewRow());				
			}
			//��������
			for (int intColIndex=0;intColIndex<cols;intColIndex++)
			{
				//dt.Columns.Add(intColIndex.ToString());
				dt.Columns.Add();
				//��дĬ��ֵΪ�մ�
				dt.Columns[intColIndex].DefaultValue = "";
			}

			int i,j;
			for(i=0 ;i< rows ; i++)
			{
				dt.Rows[i][0] = (i + 1).ToString();		//����
				for(j=1 ;j< cols-3 ; j++)
				{
					dt.Rows[i][j] = (i + 1).ToString() + "��" + (j + 1).ToString() + "��";					
					dt.Rows[i][cols-3] = (j + 1).ToString() + "." + (i + 1).ToString();
					dt.Rows[i][cols-2] = (i + 1).ToString();
				}							
				dt.Rows[i][cols-1] = (double.Parse(dt.Rows[i][cols-2].ToString()) * double.Parse(dt.Rows[i][cols-3].ToString())).ToString();
			}	

			return dt;
		}

	}//End Class
}//End Namespace
